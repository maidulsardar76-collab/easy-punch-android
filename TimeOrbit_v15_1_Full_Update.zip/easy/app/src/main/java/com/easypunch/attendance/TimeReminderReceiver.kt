package com.easypunch.attendance

import android.app.AlarmManager
import android.app.BroadcastReceiver
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import java.util.Calendar

class TimeReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val kind = intent.getStringExtra("kind") ?: "in"
        val prefs = context.getSharedPreferences("timeorbit_reminders", Context.MODE_PRIVATE)
        val time = prefs.getString(kind + "_time", null)
        val enabled = prefs.getBoolean(kind + "_enabled", false)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) manager.createNotificationChannel(NotificationChannel("timeorbit_reminders", "TimeOrbit Reminders", NotificationManager.IMPORTANCE_HIGH))
        val open = PendingIntent.getActivity(context, 7410, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val title = if (kind == "out") "TimeOrbit · OUT Reminder" else "TimeOrbit · IN Reminder"
        val body = if (kind == "out") "Please check and save your OUT time." else "Please check and save your IN time."
        manager.notify(if (kind == "out") 7302 else 7301, NotificationCompat.Builder(context, "timeorbit_reminders")
            .setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle(title).setContentText(body)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(open).build())
        if (enabled && time != null && time.matches(Regex("\\d{2}:\\d{2}"))) {
            val parts = time.split(":")
            val next = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, parts[0].toInt()); set(Calendar.MINUTE, parts[1].toInt()); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0); add(Calendar.DAY_OF_YEAR, 1) }
            val nextIntent = Intent(context, TimeReminderReceiver::class.java).putExtra("kind", kind)
            val pi = PendingIntent.getBroadcast(context, if (kind == "out") 7302 else 7301, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
            else if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
            else alarm.setExact(AlarmManager.RTC_WAKEUP, next.timeInMillis, pi)
        }
    }
}
