EASY PUNCH v15.0 — SOURCE PROJECT + GITHUB ACTIONS BUILD

এই ZIP হলো সোর্স প্রজেক্ট, APK নয়। ZIP-এর ভেতরে:
- easy/ : Android Gradle project
- .github/workflows/build-apk.yml : GitHub Actions build workflow

GitHub-এ ব্যবহার:
1) ZIP Extract করো।
2) Extract করা ফোল্ডারের ভেতরের easy ফোল্ডার এবং .github ফোল্ডারসহ সব ফাইল/ফোল্ডার repository root-এ আপলোড করো।
   গুরুত্বপূর্ণ: ZIP ফাইলটিকে শুধু repository-তে রেখে দিলে workflow চালু হবে না; ZIP extract করে ভেতরের ফাইলগুলো upload করতে হবে।
3) Commit changes করো।
4) GitHub repository > Actions > TimeOrbit Android APK > Run workflow.
5) সবুজ টিক হলে run খুলে নিচের Artifacts থেকে Easy-Punch-v15.0-debug-APK ZIP ডাউনলোড করো; extract করে app-debug.apk ইনস্টল করো।
6) লাল ক্রস হলে failed step খুলে error দেখো; build সফল না হওয়া পর্যন্ত APK নেই।

এই source package-এ Android WebView download bridge-কে chunked transfer-এ বদলানো হয়েছে, যাতে বড় PNG/JSON/XLSX/CSV ফাইল একবারে বড় Base64 string পাঠাতে না হয়। Android PrintManager ব্যবহার করে PDF save/print flow খোলে।

GPS geofence:
Office latitude 18.4575415, longitude 73.8038399, radius 100m.
Android Settings-এ Location = Allow all the time এবং background/battery permissions প্রয়োজন হতে পারে। Geofence event Android-এর নিয়মে delayed হতে পারে; app বন্ধ থাকলে 100% instant behavior নিশ্চিত নয়। App খুললে pending events attendance data-তে sync হয়।

পরীক্ষার অবস্থা:
- ZIP structure ও JavaScript syntax পরীক্ষা করতে হবে/করা হয়েছে প্যাকেজ তৈরির সময়।
- APK-কে বাস্তব ফোনে install করে PDF/PNG/XLSX/CSV ও app-closed GPS IN/OUT আলাদাভাবে পরীক্ষা করা আবশ্যক। এই ZIP-কে ফোনে tested final release বলা হচ্ছে না।
- Existing attendance data রক্ষার জন্য পুরোনো app uninstall করার আগে JSON backup নাও।


TimeOrbit v15.0 update: Blue-Purple app branding, native Android daily IN/OUT time reminders via AlarmManager, email app compose with monthly attendance summary, responsive layout adjustments. Email compose currently includes summary in body; download PDF/Excel separately to attach manually. Test on target Android device and confirm background location and notification permissions.


TimeOrbit v15.0: native Android time reminders are scheduled with AlarmManager and restored after device boot. Email report opens the configured email app with a monthly summary; PDF/Excel attachments must be attached manually. GPS geofence still requires Android Location permissions including Allow all the time, notification permission, and vendor battery settings. Device testing is required.


TimeOrbit v15.1 attendance geofence note:
- Native geofence receiver can capture enter/exit timestamps while the WebView is closed and posts a notification.
- Because WebView localStorage cannot be safely written while the app UI is closed, queued events are merged into the attendance record when TimeOrbit is next opened/foregrounded.
- This does NOT guarantee that the record appears in the WebView database instantly while the app stays closed. Android may delay geofence events; Force Stop, revoked background location, or battery restrictions can prevent events. Test on the target phone.
