package com.easypunch.attendance

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.webChromeClient = WebChromeClient()
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                GeofenceManager.register(this@MainActivity)
            }
        }
        web.addJavascriptInterface(NativeBridge(), "EasyPunchNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        requestNeededPermissions()
    }
    private fun requestNeededPermissions() {
        val missing = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.POST_NOTIFICATIONS)
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 41)
        if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            AlertDialog.Builder(this).setTitle("Allow background location").setMessage("For automatic IN/OUT while Easy Punch is not open, set Location permission to Allow all the time in Android Settings.").setPositiveButton("Open Settings") { _, _ ->
                try { startActivity(android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName"))) } catch (_: Exception) {}
            }.setNegativeButton("Later", null).show()
        }
    }
    inner class NativeBridge {
        @JavascriptInterface fun consumePendingPunches(): String {
            val prefs = getSharedPreferences(GeofenceReceiver.PREFS, MODE_PRIVATE)
            val raw = prefs.getString(GeofenceReceiver.QUEUE, "[]") ?: "[]"
            // Peek only: do not delete events until the web UI confirms it saved them.
            return try { JSONArray(raw).toString() } catch (_: Exception) { "[]" }
        }
        @JavascriptInterface fun acknowledgePendingPunches() {
            getSharedPreferences(GeofenceReceiver.PREFS, MODE_PRIVATE).edit()
                .putString(GeofenceReceiver.QUEUE, "[]").commit()
        }
    }
}
