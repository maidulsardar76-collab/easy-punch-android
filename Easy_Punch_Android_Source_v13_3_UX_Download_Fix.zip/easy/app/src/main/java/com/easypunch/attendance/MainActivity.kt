package com.easypunch.attendance

import android.Manifest
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.GeolocationPermissions
import android.webkit.DownloadListener
import android.app.DownloadManager
import android.content.ContentValues
import android.os.Environment
import android.provider.MediaStore
import android.print.PrintManager
import android.util.Base64
import java.io.File
import java.io.FileOutputStream
import android.webkit.URLUtil
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.setGeolocationEnabled(true)
        web.settings.allowContentAccess = true
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                val fine = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val coarse = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                callback?.invoke(origin, fine || coarse, false)
            }
        }
        web.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    val request = DownloadManager.Request(android.net.Uri.parse(url))
                    request.setMimeType(mimeType)
                    request.addRequestHeader("User-Agent", userAgent ?: "")
                    request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                    request.setDescription("Downloading Easy Punch file")
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                    (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                }
            } catch (_: Exception) { }
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                requestNeededPermissions()
                GeofenceManager.register(this@MainActivity)
            }
        }
        web.addJavascriptInterface(NativeBridge(), "EasyPunchNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        requestNeededPermissions()
    }
    private fun requestNeededPermissions() {
        val missing = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.POST_NOTIFICATIONS)
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 41)
        if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED && !isFinishing) {
            AlertDialog.Builder(this).setTitle("Allow background location").setMessage("For automatic IN/OUT while Easy Punch is not open, set Location permission to Allow all the time in Android Settings.").setPositiveButton("Open Settings") { _, _ ->
                try { startActivity(android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName"))) } catch (_: Exception) {}
            }.setNegativeButton("Later", null).show()
        }
    }
    inner class NativeBridge {
        @JavascriptInterface fun consumePendingPunches(): String {
            val prefs = getSharedPreferences(GeofenceReceiver.PREFS, MODE_PRIVATE)
            val raw = prefs.getString(GeofenceReceiver.QUEUE, "[]") ?: "[]"
            // Peek only: do not delete events until the web UI confirms it saved them.
            return try { JSONArray(raw).toString() } catch (_: Exception) { "[]" }
        }
        @JavascriptInterface fun acknowledgePendingPunches() {
            getSharedPreferences(GeofenceReceiver.PREFS, MODE_PRIVATE).edit()
                .putString(GeofenceReceiver.QUEUE, "[]").commit()
        }
        @JavascriptInterface fun saveDownload(base64Data: String, fileName: String, mimeType: String): String {
            return try {
                val safeName = fileName.substringAfterLast('/').substringAfterLast('\\')
                    .replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "easy-punch-download" }
                val bytes = Base64.decode(base64Data, Base64.DEFAULT)
                val mime = mimeType.ifBlank { "application/octet-stream" }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: return "ERROR: Could not create file in Downloads"
                    contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                        ?: return "ERROR: Could not open file for writing"
                    values.clear()
                    values.put(MediaStore.Downloads.IS_PENDING, 0)
                    contentResolver.update(uri, values, null, null)
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (!dir.exists()) dir.mkdirs()
                    FileOutputStream(File(dir, safeName)).use { it.write(bytes) }
                }
                "OK"
            } catch (e: Exception) {
                "ERROR: ${e.message ?: "Unable to save file"}"
            }
        }

        @JavascriptInterface fun printPage() {
            runOnUiThread {
                try {
                    val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val adapter = web.createPrintDocumentAdapter("Easy Punch Report")
                    manager.print("Easy Punch Report", adapter, android.print.PrintAttributes.Builder().build())
                } catch (e: Exception) {
                    android.widget.Toast.makeText(this@MainActivity, "Could not open PDF/print: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
