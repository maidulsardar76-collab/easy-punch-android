package com.easypunch.attendance

import android.Manifest
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices

object GeofenceManager {
    const val OFFICE_LAT = 18.4575415
    const val OFFICE_LON = 73.8038399
    const val RADIUS_METERS = 100f
    private fun pendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, GeofenceReceiver::class.java)
        return PendingIntent.getBroadcast(context, 880, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }
    fun register(context: Context) {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED) return
        val fence = Geofence.Builder().setRequestId("EASY_PUNCH_OFFICE").setCircularRegion(OFFICE_LAT, OFFICE_LON, RADIUS_METERS)
            .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT)
            .setLoiteringDelay(60_000).setExpirationDuration(Geofence.NEVER_EXPIRE).build()
        val request = GeofencingRequest.Builder().setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER or GeofencingRequest.INITIAL_TRIGGER_EXIT).addGeofence(fence).build()
        LocationServices.getGeofencingClient(context).addGeofences(request, pendingIntent(context))
            .addOnSuccessListener { context.getSharedPreferences(GeofenceReceiver.PREFS, Context.MODE_PRIVATE).edit().putBoolean("registered", true).apply() }
    }
}
