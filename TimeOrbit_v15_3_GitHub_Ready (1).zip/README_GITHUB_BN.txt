TIMEORBIT v15.3 — GITHUB READY SOURCE PACKAGE

এই ZIP-এ v15.3 Android source এবং GitHub Actions build workflow আছে। এটি APK নয়।

GitHub Repository:
https://github.com/maidulsardar76-collab/easy-punch-android

আপলোড করার নিয়ম:
1. ZIP-টি Extract করুন।
2. Extract করা ফোল্ডারের ভেতরের easy ফোল্ডার এবং .github ফোল্ডারসহ সব ফাইল Repository-এর main branch-এর root-এ upload করুন।
3. .github/workflows/main.yml পুরোনো একই path-এর workflow-কে replace করবে।
4. Commit changes করুন।
5. GitHub > Actions-এ “Build TimeOrbit APK v15.3” workflow চালু হয়েছে কি না দেখুন। Push হলে এটি নিজে থেকেই শুরু হওয়ার কথা।
6. Build সফল হলে run খুলে Artifacts থেকে “TimeOrbit-v15.3-debug-APK” ডাউনলোড করুন। ZIP extract করে app-debug.apk পাবেন।

গুরুত্বপূর্ণ:
- শুধু source ZIP-টি repository-তে upload করলে build হবে না; ZIP extract করে ভেতরের ফাইলগুলো upload করতে হবে।
- পুরোনো attendance data বাঁচাতে পুরোনো app uninstall করার আগে JSON backup নিন।
- Background geofence Android permission, battery optimization, Google Play Services ও ফোনের নীতির ওপর নির্ভরশীল। 100% instant IN/OUT নিশ্চয়তা দেওয়া যায় না। App বন্ধ থাকা অবস্থায় queued event app পুনরায় খুললে attendance data-তে sync হবে।
- GitHub Actions build সফল হওয়া এবং বাস্তব ফোনে app-closed GPS behavior পরীক্ষা করা আলাদা বিষয়।
