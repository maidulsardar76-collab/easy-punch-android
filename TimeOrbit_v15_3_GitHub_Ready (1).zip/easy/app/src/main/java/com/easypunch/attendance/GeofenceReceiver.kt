package com.easypunch.attendance

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofencingEvent
import org.json.JSONArray
import org.json.JSONObject

class GeofenceReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val event = GeofencingEvent.fromIntent(intent) ?: return
        if (event.hasError()) return
        val kind = when (event.geofenceTransition) { Geofence.GEOFENCE_TRANSITION_ENTER -> "in"; Geofence.GEOFENCE_TRANSITION_EXIT -> "out"; else -> return }
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString(QUEUE, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }
        val now = System.currentTimeMillis()
        // Keep a durable native event ledger. Events survive process death and are
        // only acknowledged after the WebView confirms it has persisted them.
        if (old.length() > 0) {
            val last = old.optJSONObject(old.length()-1)
            if (last != null && last.optString("kind") == kind && now-last.optLong("timestamp") < 180_000) return
        }
        old.put(JSONObject().put("kind", kind).put("timestamp", now).put("source", "android_geofence"))
        // Bound storage while preserving recent unconsumed events.
        val bounded = JSONArray()
        for (i in (old.length()-200).coerceAtLeast(0) until old.length()) bounded.put(old.getJSONObject(i))
        if (!prefs.edit().putString(QUEUE, bounded.toString()).commit()) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as android.app.NotificationManager
        if (android.os.Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(android.app.NotificationChannel("easy_punch", "TimeOrbit Attendance", android.app.NotificationManager.IMPORTANCE_DEFAULT))
        val builder = if (android.os.Build.VERSION.SDK_INT >= 26) android.app.Notification.Builder(context, "easy_punch") else android.app.Notification.Builder(context)
        builder.setSmallIcon(android.R.drawable.ic_menu_mylocation).setContentTitle(if(kind=="in") "TimeOrbit · Office entered" else "TimeOrbit · Office exited")
            .setContentText(if(kind=="in") "Entry time safely recorded on this phone. Open TimeOrbit to update reports." else "Exit time safely recorded on this phone. Open TimeOrbit to update reports.")
        nm.notify(if(kind=="in") 8101 else 8102, builder.build())
    }
    companion object { const val PREFS = "easy_punch_native"; const val QUEUE = "pending_punches" }
}
