PUNCH v15.4 — ANDROID SOURCE + GITHUB ACTIONS BUILD

এটি Android source project; APK নয়। Project path: easy/ এবং build workflow: .github/workflows/main.yml.

GitHub upload:
1) ZIP extract করুন।
2) ZIP-এর ভেতরের easy/ এবং .github/ folder repository root-এ upload করুন; ZIP-টিকে শুধু রেখে দেবেন না।
3) Commit changes করুন।
4) Repository → Actions → Build Punch Android APK v15.4 → Run workflow.
5) Build green হলে Artifacts থেকে Punch-v15.4-debug-APK ডাউনলোড করুন; ZIP extract করে app-debug.apk ইনস্টল করুন।

App identity: Punch; Android applicationId: com.maidulsardar.punch; version 15.4. পুরনো Easy Punch package আলাদা থাকবে।

Attendance/backup:
- পুরনো local data আলাদা app storage-এ থাকে; নতুন Android app-এ নিজে নিজে কপি হয় না। পুরনো app থেকে JSON backup নিয়ে নতুন Punch-এ Restore ব্যবহার করুন। Restore পুরনো Easy Punch/TimeOrbit backup format গ্রহণ করে।
- পুরনো Easy Punch uninstall করবেন না যতক্ষণ না Punch-এ data restore করে সব যাচাই করছেন।

Updates in this source:
- Overtime is clamped to net worked time so it cannot exceed total work time.
- Native geofence uses the saved office coordinates and radius (30–1000m), rather than always using a hard-coded office point.
- Pending native geofence events are acknowledged only after attendance has been written to local storage and IndexedDB.
- Half-day calendar marker is shown for a completed shift with OUT at/before 1:00 PM.
- Backup accepts legacy Easy Punch and TimeOrbit JSON files; new backup name/identity is Punch.
- Service-worker cache list contains only actual asset files and has a fresh cache version.

Verification:
- JavaScript syntax checks and ZIP integrity can be run locally.
- Android Gradle build and real-device tests still must pass in GitHub Actions and on the phone. Background geofence delivery depends on Android permissions, device battery policy, and OS delivery; do not treat it as guaranteed until tested.


V15.4 নতুন ফিচার:
- Android native daily IN/OUT reminder alarms; অ্যাপ বন্ধ থাকলেও নির্ধারিত সময়ে notification দিতে পারে। Notification permission, alarm permission এবং battery policy প্রযোজ্য।
- Settings-এ email recipient সংরক্ষণ, report month নির্বাচন এবং Send Email। এটি ফোনের Email app-এ subject/body summary খুলে দেয়; PDF/Excel আলাদা ডাউনলোড করে মেইলে attach করতে হবে।
- Android geofence receiver অ্যাপ বন্ধ থাকলেও transition event queue-তে রাখে এবং notification দেয়; Punch পরেরবার খুললে event-এর সময় attendance record-এ sync হয়। Android force-stop, permission revoke, geofence delivery delay এবং manufacturer battery restrictions প্রভাব ফেলতে পারে।

এই সোর্সে JavaScript syntax check করা হয়েছে; Android Gradle build এবং বাস্তব ফোনে background tests GitHub Actions/ডিভাইসে চালিয়ে নিশ্চিত করতে হবে।

GitHub-এ ZIP extract করে easy/ এবং .github/ ফোল্ডার repository root-এ upload করুন। Existing .github/workflows/main.yml overwrite করতে হবে; ZIP-কে শুধু repository-তে রেখে দিলে build হবে না।
