plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.easypunch.attendance"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.maidulsardar.punch"
        minSdk = 26
        targetSdk = 35
        versionCode = 11
        versionName = "15.4"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.gms:play-services-location:21.3.0")
}
