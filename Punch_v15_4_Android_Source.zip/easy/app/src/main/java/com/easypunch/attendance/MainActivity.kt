package com.easypunch.attendance

import android.Manifest
import android.app.AlertDialog
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.GeolocationPermissions
import android.webkit.DownloadListener
import android.app.DownloadManager
import android.content.ContentValues
import android.os.Environment
import android.provider.MediaStore
import android.print.PrintManager
import android.util.Base64
import java.io.File
import java.io.FileOutputStream
import android.webkit.URLUtil
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.setGeolocationEnabled(true)
        web.settings.allowContentAccess = true
        web.webChromeClient = object : WebChromeClient() {
            override fun onGeolocationPermissionsShowPrompt(origin: String?, callback: GeolocationPermissions.Callback?) {
                val fine = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                val coarse = ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                callback?.invoke(origin, fine || coarse, false)
            }
        }
        web.setDownloadListener { url, userAgent, contentDisposition, mimeType, _ ->
            try {
                if (url != null && (url.startsWith("http://") || url.startsWith("https://"))) {
                    val request = DownloadManager.Request(android.net.Uri.parse(url))
                    request.setMimeType(mimeType)
                    request.addRequestHeader("User-Agent", userAgent ?: "")
                    request.setTitle(URLUtil.guessFileName(url, contentDisposition, mimeType))
                    request.setDescription("Downloading Punch file")
                    request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, URLUtil.guessFileName(url, contentDisposition, mimeType))
                    (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                }
            } catch (_: Exception) { }
        }
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                requestNeededPermissions()
                GeofenceManager.register(this@MainActivity)
            }
        }
        web.addJavascriptInterface(NativeBridge(), "EasyPunchNative")
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
        requestNeededPermissions()
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 41 && grantResults.isNotEmpty() && grantResults.any { it == PackageManager.PERMISSION_GRANTED }) {
            GeofenceManager.register(this)
        }
    }
    private fun requestNeededPermissions() {
        val missing = mutableListOf<String>()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.POST_NOTIFICATIONS)
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 41)
        if (Build.VERSION.SDK_INT >= 29 && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED && !isFinishing) {
            AlertDialog.Builder(this).setTitle("Allow background location").setMessage("For automatic IN/OUT while Punch is not open, set Location permission to Allow all the time in Android Settings.").setPositiveButton("Open Settings") { _, _ ->
                try { startActivity(android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.parse("package:$packageName"))) } catch (_: Exception) {}
            }.setNegativeButton("Later", null).show()
        }
    }
    inner class NativeBridge {
        @JavascriptInterface fun scheduleDailyReminder(kind: String, time: String, enabled: Boolean): String {
            return try {
                if (!kind.matches(Regex("in|out"))) return "ERROR: Invalid reminder type"
                val alarm = getSystemService(Context.ALARM_SERVICE) as AlarmManager
                getSharedPreferences("timeorbit_reminders", MODE_PRIVATE).edit().putString(kind + "_time", time).putBoolean(kind + "_enabled", enabled).apply()
                val requestCode = if (kind == "in") 7301 else 7302
                val intent = Intent(this@MainActivity, TimeReminderReceiver::class.java).putExtra("kind", kind)
                val pending = PendingIntent.getBroadcast(this@MainActivity, requestCode, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
                alarm.cancel(pending)
                if (enabled && time.matches(Regex("\\d{2}:\\d{2}"))) {
                    val parts = time.split(":"); val cal = java.util.Calendar.getInstance().apply {
                        set(java.util.Calendar.HOUR_OF_DAY, parts[0].toInt()); set(java.util.Calendar.MINUTE, parts[1].toInt()); set(java.util.Calendar.SECOND, 0); set(java.util.Calendar.MILLISECOND, 0)
                        if (timeInMillis <= System.currentTimeMillis()) add(java.util.Calendar.DAY_OF_YEAR, 1)
                    }
                    if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
                    else if (Build.VERSION.SDK_INT >= 23) alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
                    else alarm.setExact(AlarmManager.RTC_WAKEUP, cal.timeInMillis, pending)
                }
                "OK"
            } catch (e: Exception) { "ERROR: ${e.message ?: "Unable to schedule reminder"}" }
        }
        @JavascriptInterface fun openEmail(to: String, subject: String, body: String): String {
            return try {
                val intent = Intent(Intent.ACTION_SENDTO).apply {
                    data = Uri.parse("mailto:")
                    putExtra(Intent.EXTRA_EMAIL, arrayOf(to.trim()))
                    putExtra(Intent.EXTRA_SUBJECT, subject.take(160))
                    putExtra(Intent.EXTRA_TEXT, body.take(120000))
                }
                startActivity(Intent.createChooser(intent, "Send Punch report by email"))
                "OK"
            } catch (e: Exception) { "ERROR: ${e.message ?: "No email app available"}" }
        }
        @JavascriptInterface fun configureGeofence(lat: Double, lon: Double, radius: Int): String {
            return try {
                if (lat !in -90.0..90.0 || lon !in -180.0..180.0 || radius !in 30..1000) return "ERROR: Invalid office location or radius"
                getSharedPreferences(GeofenceManager.PREFS, MODE_PRIVATE).edit()
                    .putFloat("lat", lat.toFloat()).putFloat("lon", lon.toFloat()).putInt("radius", radius).commit()
                GeofenceManager.register(this@MainActivity)
                "OK"
            } catch (e: Exception) { "ERROR: ${e.message ?: "Unable to configure geofence"}" }
        }
        @JavascriptInterface fun consumePendingPunches(): String {
            val prefs = getSharedPreferences(GeofenceReceiver.PREFS, MODE_PRIVATE)
            val raw = prefs.getString(GeofenceReceiver.QUEUE, "[]") ?: "[]"
            // Peek only: do not delete events until the web UI confirms it saved them.
            return try { JSONArray(raw).toString() } catch (_: Exception) { "[]" }
        }
        @JavascriptInterface fun acknowledgePendingPunches() {
            getSharedPreferences(GeofenceReceiver.PREFS, MODE_PRIVATE).edit()
                .putString(GeofenceReceiver.QUEUE, "[]").commit()
        }
        @JavascriptInterface fun beginDownload(fileName: String, mimeType: String): String {
            return try {
                val safeName = sanitizeDownloadName(fileName)
                val temp = File(cacheDir, "ep_download_" + safeName.hashCode().toUInt().toString(16) + ".part")
                temp.delete()
                val meta = getSharedPreferences("easy_punch_downloads", MODE_PRIVATE)
                meta.edit().putString("active_path", temp.absolutePath)
                    .putString("active_name", safeName)
                    .putString("active_mime", mimeType.ifBlank { "application/octet-stream" }).commit()
                if (!temp.createNewFile()) return "ERROR: Could not create temporary file"
                "OK"
            } catch (e: Exception) { "ERROR: ${e.message ?: "Could not start download"}" }
        }

        @JavascriptInterface fun appendDownloadChunk(base64Chunk: String): String {
            return try {
                val meta = getSharedPreferences("easy_punch_downloads", MODE_PRIVATE)
                val path = meta.getString("active_path", null) ?: return "ERROR: Download session missing"
                val temp = File(path)
                if (!temp.exists()) return "ERROR: Temporary file missing"
                val bytes = Base64.decode(base64Chunk, Base64.DEFAULT)
                FileOutputStream(temp, true).use { it.write(bytes) }
                "OK"
            } catch (e: Exception) { "ERROR: ${e.message ?: "Could not write download chunk"}" }
        }

        @JavascriptInterface fun finishDownload(): String {
            val meta = getSharedPreferences("easy_punch_downloads", MODE_PRIVATE)
            val path = meta.getString("active_path", null) ?: return "ERROR: Download session missing"
            val safeName = meta.getString("active_name", "easy-punch-download") ?: "easy-punch-download"
            val mime = meta.getString("active_mime", "application/octet-stream") ?: "application/octet-stream"
            val temp = File(path)
            return try {
                if (!temp.exists() || temp.length() == 0L) return "ERROR: Download is empty"
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                        put(MediaStore.Downloads.MIME_TYPE, mime)
                        put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
                        put(MediaStore.Downloads.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
                        ?: return "ERROR: Could not create file in Downloads"
                    try {
                        contentResolver.openOutputStream(uri)?.use { out -> temp.inputStream().use { it.copyTo(out) } }
                            ?: return "ERROR: Could not open file for writing"
                        values.clear(); values.put(MediaStore.Downloads.IS_PENDING, 0)
                        contentResolver.update(uri, values, null, null)
                    } catch (e: Exception) { contentResolver.delete(uri, null, null); throw e }
                } else {
                    val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    if (!dir.exists()) dir.mkdirs()
                    FileOutputStream(File(dir, safeName)).use { out -> temp.inputStream().use { it.copyTo(out) } }
                }
                temp.delete()
                meta.edit().clear().commit()
                "OK"
            } catch (e: Exception) { "ERROR: ${e.message ?: "Unable to save file"}" }
        }

        @JavascriptInterface fun cancelDownload() {
            val meta = getSharedPreferences("easy_punch_downloads", MODE_PRIVATE)
            meta.getString("active_path", null)?.let { File(it).delete() }
            meta.edit().clear().commit()
        }

        private fun sanitizeDownloadName(fileName: String): String = fileName.substringAfterLast('/').substringAfterLast('\\')
            .replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "easy-punch-download" }

        @JavascriptInterface fun printPage() {
            runOnUiThread {
                try {
                    val manager = getSystemService(Context.PRINT_SERVICE) as PrintManager
                    val adapter = web.createPrintDocumentAdapter("Punch Report")
                    manager.print("Punch Report", adapter, android.print.PrintAttributes.Builder().build())
                } catch (e: Exception) {
                    android.widget.Toast.makeText(this@MainActivity, "Could not open PDF/print: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }
    }
}
