EASY PUNCH ANDROID SOURCE — v15.4 BACKGROUND QUEUE SAFETY UPDATE

এটি APK নয়; Android APK তৈরির সোর্স প্রজেক্ট। বর্তমান Punch v12-26 UI/assets রাখা হয়েছে যাতে design যতটা সম্ভব একই থাকে। পুরনো attendance data migrate করা হয় না।

অফিস Geofence: 18.4575415, 73.8038399; radius 100m.

এই আপডেটে:
- Android Geofencing API ENTER/EXIT ইভেন্ট গ্রহণ করে।
- ইভেন্টের timestamp SharedPreferences-এ synchronous commit দিয়ে সেভ করা হয়।
- অ্যাপ খুললে WebView attendance data-তে ইভেন্ট apply/persist হওয়ার পরই native queue acknowledge/clear হয়; আগেভাগে queue মুছে যাওয়ার ঝুঁকি কমানো হয়েছে।
- Duplicate same-kind transitions within 3 minutes are ignored.
- Notification জানায় background event ধরা হয়েছে।

সীমাবদ্ধতা ও জরুরি বিষয়:
1) এখানে Android SDK দিয়ে compile করা বা বাস্তব ফোনে পরীক্ষা করা হয়নি। তাই APK build ও real background geofence behavior এখনও যাচাই করা আবশ্যক।
2) অ্যাপ বন্ধ থাকলে Android native storage-এ event রাখা হয়; অ্যাপের UI বন্ধ অবস্থায় দেখাতে পারে না। অ্যাপ আবার খুললে attendance UI-তে sync হয়।
3) Android Settings-এ Location permission “Allow all the time”, Precise Location এবং প্রয়োজনমতো notifications চালু করতে হবে। Battery restrictions, manufacturer settings, reboot এবং Force Stop geofence delivery প্রভাবিত করতে পারে।
4) Chrome/PWA ও Android WebView storage আলাদা। পুরনো data migrate করা হবে না; নতুন APK-তে নতুন data শুরু হবে।
5) Geofence events OS/device behaviour-এর ওপর নির্ভর করে; অফিসে ঢোকা/বেরোনোর পরে বাস্তব পরীক্ষা আবশ্যক।

GitHub Actions build:
1. GitHub-এ নতুন private repository বানান।
2. ZIP extract করে project-এর সব ফাইল repository root-এ upload করুন (settings.gradle.kts, build.gradle.kts, app/, .github/).
3. Commit changes করুন।
4. Actions → “Build Punch APK” → Run workflow.
5. Build green হলে Artifacts থেকে “Easy-Punch-APK” download করুন; তার ভেতরে app-debug.apk থাকবে।

Debug APK শুধু পরীক্ষা করার জন্য। কোড পরিবর্তন বা workflow build success মানেই background attendance বাস্তবে নিশ্চিত নয়; ফোনে পরীক্ষা করতে হবে।


Punch v15.0 update: Blue-Purple app branding, native Android daily IN/OUT time reminders via AlarmManager, email app compose with monthly attendance summary, responsive layout adjustments. Email compose currently includes summary in body; download PDF/Excel separately to attach manually. Test on target Android device and confirm background location and notification permissions.


Punch v15.0: native Android time reminders are scheduled with AlarmManager and restored after device boot. Email report opens the configured email app with a monthly summary; PDF/Excel attachments must be attached manually. GPS geofence still requires Android Location permissions including Allow all the time, notification permission, and vendor battery settings. Device testing is required.


V15.4 Update: Android native daily IN/OUT reminder alarms are scheduled from Settings. Email report supports a saved recipient, month selection, and opening the installed email app with a monthly attendance summary. Attach the downloaded PDF/Excel file manually before sending. Background geofence events are recorded by Android and synced into attendance when Punch is next opened; Android force-stop, revoked permissions, or manufacturer battery restrictions can prevent delivery.
